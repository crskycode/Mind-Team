#pragma once

typedef struct
{

}aud_export_t;

extern aud_export_t gAudExports;

#define META_AUDIO_VERSION "Meta Audio 1.1c"